# Steel Sector Data Diagnostic

## Query Generated for Steel Sector

When you select only the Steel sector, the system generates this SQL query:

```sql
SELECT * FROM (
    SELECT 
        Ticker,
        Date,
        Price
    FROM Steel
    WHERE 1=1
) AS CombinedData
ORDER BY Date DESC, Ticker
```

## Potential Issues and Solutions

### 1. Check if Steel table has data

Run this query in your SQL Server Management Studio:

```sql
-- Check if Steel table exists and has data
SELECT COUNT(*) as row_count FROM Steel;

-- See sample data
SELECT TOP 10 * FROM Steel ORDER BY Date DESC;

-- Check for NULL prices
SELECT COUNT(*) as null_price_count 
FROM Steel 
WHERE Price IS NULL;
```

### 2. Check ticker mapping in Ticker_Reference

The system maps tickers to commodity names using the Ticker_Reference table:

```sql
-- Check Steel tickers in reference table
SELECT * FROM Ticker_Reference 
WHERE Sector = 'Steel' AND Active = 1;

-- Find unmapped Steel tickers
SELECT DISTINCT s.Ticker
FROM Steel s
LEFT JOIN Ticker_Reference tr ON s.Ticker = tr.Ticker
WHERE tr.Ticker IS NULL;
```

### 3. Verify data integrity

```sql
-- Check date range in Steel table
SELECT 
    MIN(Date) as earliest_date,
    MAX(Date) as latest_date,
    COUNT(DISTINCT Ticker) as unique_tickers,
    COUNT(*) as total_rows
FROM Steel;

-- Check if all Steel tickers have names
SELECT 
    s.Ticker,
    tr.Name,
    COUNT(*) as price_points
FROM Steel s
LEFT JOIN Ticker_Reference tr ON s.Ticker = tr.Ticker
GROUP BY s.Ticker, tr.Name
ORDER BY s.Ticker;
```

## Data Flow for Steel Sector

1. **Query Builder** (`modules/query_builder.py`):
   - Generates SELECT query for Steel table
   - Returns columns: Ticker, Date, Price

2. **Data Loader** (`modules/data_loader.py`):
   - Maps Ticker → Name using Ticker_Reference
   - Creates 'Commodities' column from the Name
   - If ticker not found in reference, row gets Commodities = None

3. **Calculations** (`modules/calculations.py`):
   - Calculates %Day, %Week, %Month, etc.
   - Filters out rows where Commodities is None

## Common Issues

### Issue: "None -100%" in display
**Cause**: Ticker exists in Steel table but not in Ticker_Reference
**Solution**: Add missing tickers to Ticker_Reference table

### Issue: No data displayed for Steel
**Cause**: 
- Steel table is empty
- All Steel tickers are unmapped
- All prices are NULL

**Solution**: 
1. Verify Steel table has data
2. Ensure Ticker_Reference has all Steel tickers
3. Check for NULL prices

## Quick Fix SQL

If you find unmapped tickers, add them to Ticker_Reference:

```sql
-- Example: Add missing Steel ticker
INSERT INTO Ticker_Reference (Ticker, Name, Sector, Data_Source, Active)
VALUES ('STEEL_TICKER', 'Steel Product Name', 'Steel', 'YourSource', 1);
```

## Testing in Python

To test the data flow, you can check each step:

```python
import os
os.environ['DC_DB_STRING'] = 'your_connection_string'

from modules.data_loader import load_data_from_database

# Load data
df_data, df_list = load_data_from_database()

# Check Steel data
if df_data is not None:
    steel_data = df_data[df_data['Commodities'].str.contains('steel', case=False, na=False)]
    print(f"Steel commodities found: {steel_data['Commodities'].unique()}")
    print(f"Steel data points: {len(steel_data)}")
    
    # Check for None values
    none_commodities = df_data[df_data['Commodities'].isna()]
    if not none_commodities.empty:
        print(f"\nTickers with no name mapping:")
        print(none_commodities['Ticker_Code'].unique())
```