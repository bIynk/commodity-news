"""Commodity AI Dashboard Source Package"""

__version__ = "1.0.0"