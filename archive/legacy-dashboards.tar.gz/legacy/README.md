# Legacy Files Archive

This directory contains the original project files before the migration to the unified structure.

## Directory Contents

### `/ai-dashboard-original/`
**Original AI-powered dashboard files** (moved from root)
- `app.py` - Original Streamlit entry point (identical to `/current/ai-dashboard/main.py`)
- `src/` - Original source code directory (identical to `/current/ai-dashboard/src/`)
- `config.yaml` - Original configuration file

**Status:** These files are now duplicated in `/current/ai-dashboard/`
**Run command (deprecated):** `streamlit run legacy/ai-dashboard-original/app.py`

### `/sql-dashboard-original/`
**Original SQL Server dashboard** (moved from `/Commodities-Dashboard-v2/`)
- `Commodities-Dashboard-v2/` - Complete original SQL dashboard
  - `Home.py` - Main entry point (identical to `/current/sql-dashboard/main.py`)
  - `modules/` - Core functionality modules
  - `pages/` - Additional pages
  - All supporting files

**Status:** These files are now duplicated in `/current/sql-dashboard/`
**Run command (deprecated):** `streamlit run legacy/sql-dashboard-original/Commodities-Dashboard-v2/Home.py`

### `Home_backup.py`
Backup file from SQL dashboard development

## Important Notes

1. **These files are deprecated** - Use `/current/` directories for active development
2. **Files were copied, not moved** during Phase 2 migration, so these are duplicates
3. **Kept for reference only** - Will be removed after Phase 7 (final cleanup)
4. **Do not modify these files** - All changes should be made in `/current/` or `/unified/`

## Migration Timeline
- **Date Archived:** January 17, 2025
- **Migration Phase:** Post-Phase 3 cleanup
- **Planned Removal:** After Phase 7 completion

---
*Part of the Commodity AI Dashboard migration project*