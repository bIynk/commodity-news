# AI-MSSQL Migration Plan

**Status:** 🟢 COMPLETED
**Created:** December 2024
**Completed:** December 2024
**Result:** Successfully migrated - AI Dashboard now uses MSSQL with shared database

## Goal
Integrate AI Dashboard with the shared Microsoft SQL Server database used by SQL Dashboard, designing new table schemas that conform to existing database conventions for storing Perplexity AI query results and market intelligence.

## Key Considerations
- **Single Backend**: MSSQL only - no SQLite, no dual backend complexity
- **Database Conventions**: Composite primary keys, DECIMAL(18,6) for numerics, indexed Date columns
- **AI Commodities**: Use natural commodity names ("iron ore", "coking coal") as received from Perplexity API
- **Fresh Start**: No data migration - start collecting new data in MSSQL

## Step-by-Step Plan

### Phase 1: Database Schema Design
1. Create new tables in MSSQL for AI-specific data:
   ```sql
   -- Cache Perplexity API responses
   CREATE TABLE AI_Query_Cache (
       Commodity VARCHAR(50) NOT NULL,  -- Natural name: "iron ore", "coking coal"
       Query_Date DATE NOT NULL,
       Timeframe VARCHAR(20) NOT NULL,
       Query_Response NVARCHAR(MAX),  -- Full JSON response
       Created_At DATETIME2 DEFAULT GETDATE(),
       Expires_At DATETIME2,
       Cache_Hit_Count INT DEFAULT 0,
       PRIMARY KEY (Commodity, Query_Date, Timeframe)
   );
   CREATE INDEX idx_ai_cache_expires ON AI_Query_Cache(Expires_At);

   -- Store processed market intelligence
   CREATE TABLE AI_Market_Intelligence (
       Commodity VARCHAR(50) NOT NULL,
       Analysis_Date DATE NOT NULL,
       Trend VARCHAR(20),  -- bullish/bearish/stable
       Key_Drivers NVARCHAR(MAX),  -- JSON array of drivers
       Current_Price DECIMAL(18,6),
       Price_Unit VARCHAR(20),
       Price_Change_Pct DECIMAL(18,6),
       Confidence_Score DECIMAL(18,6),
       Created_At DATETIME2 DEFAULT GETDATE(),
       PRIMARY KEY (Commodity, Analysis_Date)
   );
   CREATE INDEX idx_ai_intelligence_date ON AI_Market_Intelligence(Analysis_Date DESC);

   -- Store news items from AI queries
   CREATE TABLE AI_News_Items (
       News_ID INT IDENTITY(1,1) PRIMARY KEY,
       Commodity VARCHAR(50),
       News_Date DATE,
       Headline NVARCHAR(500),
       Summary NVARCHAR(MAX),
       Source_URLs NVARCHAR(MAX),  -- JSON array
       Sentiment VARCHAR(20),
       Impact_Score DECIMAL(18,6),
       Created_At DATETIME2 DEFAULT GETDATE()
   );
   CREATE INDEX idx_news_commodity_date ON AI_News_Items(Commodity, News_Date DESC);
   ```

### Phase 2: Replace SQLite with MSSQL in AI Dashboard
1. Update `current/ai-dashboard/src/storage/database.py`:
   - Remove all SQLite code
   - Import and use `DatabaseConnection` from SQL Dashboard
   - Implement all methods using MSSQL:
     ```python
     class CommodityDatabase:
         def __init__(self):
             self.db = get_db_connection()  # From SQL Dashboard

         def save_query_cache(self, commodity, query_date, timeframe, response)
         def get_cached_query(self, commodity, query_date, timeframe)
         def save_market_intelligence(self, commodity, analysis_data)
         def save_news_items(self, commodity, news_items)
         def cleanup_expired_cache(self)
     ```

2. Delete `current/ai-dashboard/src/storage/mssql_database.py` (no longer needed)

### Phase 3: Update Query Orchestration
1. Modify `current/ai-dashboard/src/api/commodity_queries.py`:
   - Remove SQLite references
   - Use MSSQL for all caching operations
   - Update cache checking logic to query AI_Query_Cache table

2. Update imports and initialization:
   - Remove SQLite imports
   - Use shared database connection from SQL Dashboard

### Phase 4: Configuration Updates
1. Update `config.yaml`:
   ```yaml
   database:
     cache_duration_hours: 24
     cleanup_interval_hours: 48
     # Connection string from environment variable DC_DB_STRING
   ```

2. Remove SQLite database files:
   - Delete `data/commodity_data.db`
   - Update `.gitignore` to remove SQLite references

### Phase 5: Testing & Documentation
1. Create SQL script `scripts/create_ai_tables.sql`:
   - Include all CREATE TABLE statements
   - Add cleanup script for old cache entries
   - Include sample queries for verification

2. Update documentation:
   - Remove references to SQLite in README
   - Update setup instructions to mention MSSQL requirement
   - Document the new AI tables in database schema docs

3. Create tests:
   - Test MSSQL connection
   - Test cache operations
   - Test data persistence
   - Verify both dashboards work with shared database

## Parallelization Opportunities
**Can be done in parallel after Phase 1:**
- Agent 1: Create and execute SQL schema in database
- Agent 2: Update database.py to use MSSQL only
- Agent 3: Update commodity_queries.py
- Agent 4: Update documentation and create tests

**Dependencies:**
- Phase 1 must complete first (schema creation)
- Phases 2-3 can run in parallel after Phase 1
- Phase 4 requires Phase 2-3
- Phase 5 can start after Phase 1

## Validation
- **Schema Creation**: Verify all tables created with proper indexes
- **Data Operations**: Test CRUD operations on all AI tables
- **Cache Performance**: Queries return in <100ms
- **Connection Pooling**: Verify reuse of SQL Dashboard's connection pool
- **Both Dashboards**: Confirm both can access the shared database
- **No SQLite**: Ensure all SQLite code and files removed

## Implementation Status
- [x] Phase 1: Database Schema Design - ✅ COMPLETED
- [x] Phase 2: Replace SQLite with MSSQL in AI Dashboard - ✅ COMPLETED
- [x] Phase 3: Update Query Orchestration - ✅ COMPLETED
- [x] Phase 4: Configuration Updates - ✅ COMPLETED
- [x] Phase 5: Testing & Documentation - ✅ COMPLETED

## Completion Summary
All phases successfully completed. The AI Dashboard now:
- Uses MSSQL Server exclusively (no SQLite)
- Shares the same database with SQL Dashboard
- Has AI_Query_Cache, AI_Market_Intelligence, and AI_News_Items tables created
- Uses DC_DB_STRING_MASTER for write operations
- Imports DatabaseConnection from SQL Dashboard modules

## Notes
- This plan migrates the AI Dashboard from SQLite to MSSQL only (no dual backend)
- AI commodities are stored with their natural names from Perplexity API
- The system reuses the existing database connection infrastructure from SQL Dashboard
- No historical data migration is needed - starting fresh with MSSQL