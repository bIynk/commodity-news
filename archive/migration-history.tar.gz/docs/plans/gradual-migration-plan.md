# Gradual Migration Plan

**Status:** ⚫ ARCHIVED
**Created:** December 2024
**Archived:** January 2025
**Reason:** Superseded by AI-SQL Unified Dashboard approach
**Note:** Original plan for gradual consolidation, replaced with direct port strategy

## Goal
Implement a gradual migration strategy to reorganize the messy repository structure by creating parallel directory structures (`/current` for working code, `/unified` for new clean structure, `/legacy` for archives) while maintaining system stability and enabling incremental migration.

## Key Considerations
- **Zero downtime requirement** - Both dashboards must remain functional throughout migration
- **Preserve git history** - Use `git mv` commands to maintain file history
- **Dependencies isolation** - Keep separate requirements.txt during transition
- **Config management** - Gradual consolidation of configuration files
- **Documentation consolidation** - Create single source of truth for docs
- **Existing patterns to reuse**:
  - `/src` structure from AI dashboard (good separation)
  - `/modules` pattern from SQL dashboard (clear features)
  - Caching strategies from both systems
  - Database connection pooling from SQL dashboard

## Step-by-Step Plan

### Phase 1: Create Migration Infrastructure
1. **Create migration structure** (`/current`, `/unified`, `/legacy`, `MIGRATION.md`)
2. **Move documentation** to `/unified/docs` with proper categorization
3. **Create migration tracking** file to log progress
4. **Set up git workflow** for preserving history

### Phase 2: Preserve Current Working Code
5. **Move AI Dashboard** from root to `/current/ai-dashboard/`
   - Move `app.py` → `/current/ai-dashboard/main.py`
   - Move `/src` → `/current/ai-dashboard/src/`
   - Move AI-specific configs and requirements
6. **Move SQL Dashboard** from `/Commodities-Dashboard-v2` to `/current/sql-dashboard/`
   - Move `Home.py` → `/current/sql-dashboard/main.py`
   - Move `/modules` and `/pages` preserving structure
   - Move dashboard-specific requirements
7. **Archive obsolete files** to `/legacy/`
   - `Home_backup.py` and other backup files
   - Old documentation versions
   - Unused scripts

### Phase 3: Build Unified Structure
8. **Create shared infrastructure** in `/unified/shared/`
   - Extract common database utilities
   - Create unified caching module
   - Build ticker mapping service
   - Consolidate logging configuration
9. **Set up unified config** in `/unified/config/`
   - Create base configuration
   - Environment-specific overrides
   - Consolidate API keys and connection strings
10. **Create feature modules** in `/unified/src/features/`
    - `/ai_insights/` - Perplexity integration
    - `/market_data/` - SQL Server real-time data
    - `/analytics/` - Z-scores, calculations
    - `/ui_components/` - Shared UI elements

### Phase 4: Migration Scripts
11. **Create migration utilities** in `/scripts/`
    - `migrate_database.py` - Database migration tool
    - `sync_configs.py` - Config synchronization
    - `test_migration.py` - Validation scripts
12. **Build compatibility layer**
    - Import redirects for gradual migration
    - Backward compatibility shims
    - Feature flags for switching between old/new

### Phase 5: Incremental Feature Migration
13. **Migrate shared components first**
    - Database connections
    - Caching logic
    - Data models
14. **Migrate AI dashboard features**
    - Perplexity client
    - Query orchestration
    - News processing
15. **Migrate SQL dashboard features**
    - Real-time data loading
    - AG-Grid configuration
    - Performance charts

### Phase 6: Testing and Validation
16. **Create comprehensive tests** in `/unified/tests/`
    - Unit tests for shared components
    - Integration tests for data flow
    - E2E tests for both dashboards
17. **Parallel run validation**
    - Run both old and new versions
    - Compare outputs
    - Performance benchmarking

### Phase 7: Documentation and Cleanup
18. **Update all documentation**
    - Single README.md with clear structure
    - Migration guide for developers
    - Updated setup instructions
19. **Create deployment scripts**
    - Docker configuration if needed
    - CI/CD pipeline updates
    - Environment setup automation
20. **Final cleanup**
    - Remove `/current` after full migration
    - Archive any remaining legacy code
    - Update all import paths

## Parallelization Opportunities

### Can be done in parallel:
- **Team A**: Steps 5-7 (Preserve current code)
- **Team B**: Steps 8-10 (Build unified structure)
- **Team C**: Step 2 (Documentation consolidation)

### Sequential dependencies:
1. Step 1 must complete first (create structure)
2. Steps 5-7 must complete before 13-15 (need working baseline)
3. Steps 8-10 must complete before 13-15 (need unified structure)
4. Steps 16-17 must happen after 13-15 (need migrated code to test)

### Independent workstreams:
- Documentation (Step 2, 18) can progress independently
- Migration scripts (Step 11-12) can be developed early
- Test framework (Step 16) can be set up in advance

## Validation

### Success Criteria:
1. **Both dashboards functional** - No breaking changes during migration
2. **Git history preserved** - Can trace file history through migration
3. **Tests passing** - All existing functionality maintained
4. **Performance maintained** - No degradation in response times
5. **Documentation complete** - Single source of truth established

### Validation Checklist:
- [ ] AI dashboard loads and queries Perplexity successfully
- [ ] SQL dashboard connects and displays real-time data
- [ ] All caching mechanisms working
- [ ] Configuration properly separated by environment
- [ ] Import paths updated and working
- [ ] No hardcoded paths or credentials
- [ ] All tests passing (unit, integration, E2E)
- [ ] Documentation reflects new structure
- [ ] Old code properly archived
- [ ] Deployment scripts updated

### Metrics to Track:
- Migration progress percentage (files moved/total)
- Test coverage before/after
- Performance benchmarks (load time, query time)
- Code duplication reduction
- Documentation completeness score

## Implementation Status

**Created:** January 2025
**Status:** Planning Phase
**Next Step:** Begin Phase 1 - Create Migration Infrastructure