# Z-Score Threshold with Sector Expansion Plan

**Status:** 🟡 READY TO IMPLEMENT
**Created:** January 2025
**Priority:** HIGH - Implement BEFORE sector expansion
**Dependencies:** Existing z-score calculations, AI integration layer

## Goal
- Implement z-score threshold filtering for AI news queries to optimize API costs by only querying commodities with significant price movements (|z-score| > 2)
- Integrate this feature with the sector expansion plan from 5 to 100+ commodities
- Modify AI news display to show all news from the last week, with proper handling of multi-day queries

## Key Considerations
- **Architecture**: Z-scores already computed in `calculate_price_changes()` function
- **Dependencies**: Requires access to computed z-scores before AI query execution
- **Cost Impact**: Critical for sector expansion - reduces API calls from 100+ to ~10-20 per day
- **Existing Patterns**:
  - Z-score calculation in `modules/calculations.py`
  - AI query orchestration in `modules/ai_integration/commodity_queries.py`
  - Cache system already supports selective querying
- **Risk**: Without threshold filtering, sector expansion would increase API costs by 20x
- **News Display**: Show weekly aggregation of news, handle duplicate queries intelligently

## Step-by-Step Plan

### Phase 1: Z-Score Threshold Implementation (PRIORITY - Do First)

1. **Update `modules/ai_integration/commodity_queries.py`**:
   - Add `zscore_threshold` parameter to `CommodityQueryOrchestrator.__init__()` (default=2.0)
   - Modify `query_all_commodities()` to accept optional `commodity_zscores` dictionary
   - Filter commodities where `abs(zscore) > threshold` before querying
   - Skip API calls for commodities below threshold
   - Still check cache for all commodities (cached data is free)

2. **Update `current/sql-dashboard/main.py`**:
   - Extract z-scores from `calculate_price_changes()` results
   - Pass z-scores dictionary to `ai_orchestrator.query_all_commodities()`
   - Map commodity names to their latest z-score values

3. **Add threshold configuration**:
   - Add `AI_ZSCORE_THRESHOLD` to environment variables (default=2.0)
   - Update `modules/config.py` to read threshold setting
   - Document threshold in config.yaml

4. **Update `modules/ai_integration/data_processor.py`**:
   - Handle None results for below-threshold commodities gracefully
   - Ensure table still displays all commodities
   - Return empty news cards for skipped commodities

### Phase 2: AI News Display Enhancement

5. **Update `modules/ai_integration/ai_database.py`**:
   - Modify `get_cached_response()` to query last 7 days instead of just today
   - Add `get_weekly_news()` method to aggregate news from AI_News_Items table
   - Query: `WHERE commodity = ? AND query_date >= DATEADD(day, -7, GETDATE())`
   - Sort by query_date DESC to prioritize latest news

6. **Implement duplicate handling in `modules/ai_integration/data_processor.py`**:
   - When processing weekly news, deduplicate based on headline similarity
   - If same commodity queried multiple days, show only latest query's news
   - Add date indicator to news items (e.g., "Jan 15", "2 days ago")
   - Maintain source URLs for all displayed news

7. **Update news aggregation logic**:
   - Modify `process_query_results()` to handle weekly news aggregation
   - For each commodity, compile news from all queries in past week
   - If commodity was queried today (z-score > threshold), use fresh data
   - If not queried today but has cached data from past week, display that
   - Sort news items by date, most recent first

8. **Handle edge cases**:
   - Commodity queried Monday with high z-score, low z-score Tuesday
   - Show Monday's cached news on Tuesday (within 7-day window)
   - If queried again Wednesday with high z-score, replace with fresh data
   - Ensure no duplicate news items in display

### Phase 3: Sector Expansion (After Z-Score Implementation)

9. **Follow simplified sector expansion plan**:
   - Leverage `Ticker_Reference` table for commodity metadata
   - Create `config/news_sources.yaml` for sector-specific sources
   - Update `commodity_queries.py` to load from database
   - Remove hardcoded commodity list

10. **Database Integration**:
    - Modify `data_loader.py` to expose commodity metadata function
    - Map database tickers to natural language names for AI queries
    - Handle sectors with known mapping issues (Livestock, Fishery)

### Phase 4: Testing & Validation

11. **Create `tests/test_zscore_filtering.py`**:
    - Test threshold filtering logic
    - Verify commodities with |z-score| < 2 are skipped
    - Test cache behavior with threshold
    - Validate cost reduction metrics

12. **Create `tests/test_news_aggregation.py`**:
    - Test weekly news retrieval
    - Test duplicate query handling (same commodity, different days)
    - Verify deduplication logic
    - Test date sorting and display

13. **Integration Testing**:
    - Test with 5 steel commodities first
    - Simulate multi-day scenarios
    - Gradually expand to full sector list
    - Monitor API usage and costs

14. **Update Documentation**:
    - Document threshold configuration in README
    - Explain weekly news aggregation behavior
    - Update `.docs/architecture/ai-dashboard-design.md`
    - Add examples of multi-day query scenarios

## Parallelization Opportunities

**Sequential Requirements**:
1. Phase 1 must complete before Phase 2 (need threshold logic first)
2. Phase 1-2 must complete before Phase 3 (need cost control before expansion)

**Can be parallelized**:
- Agent 1: Core threshold implementation (Steps 1-3)
- Agent 2: News display enhancement (Steps 5-8)
- Agent 3: Test framework creation (Steps 11-12)
- Agent 4: Documentation updates (Step 14)

**After Phase 1-2 completion**:
- Agent 1: Sector configuration (Step 9)
- Agent 2: Database integration (Step 10)

## Validation
- **Threshold Logic**: Verify only |z-score| > 2 commodities trigger new API calls
- **Weekly News Display**: All commodities show news from past 7 days
- **Duplicate Handling**: Latest query replaces older queries for same commodity
- **Cache Preservation**: Cached data still returned regardless of z-score
- **Cost Metrics**: Achieve 80-90% reduction in API calls
- **Sector Expansion**: Successfully handle 100+ commodities within budget
- **Performance**: Maintain <2s load time with filtered queries

## Implementation Status
- [ ] Phase 1: Z-Score Threshold Implementation
  - [ ] Update commodity_queries.py
  - [ ] Update main.py integration
  - [ ] Add threshold configuration
  - [ ] Update data_processor.py
- [ ] Phase 2: AI News Display Enhancement
  - [ ] Update ai_database.py for weekly queries
  - [ ] Implement duplicate handling
  - [ ] Update news aggregation logic
  - [ ] Handle edge cases
- [ ] Phase 3: Sector Expansion
  - [ ] Create news_sources.yaml
  - [ ] Database integration
- [ ] Phase 4: Testing & Validation
  - [ ] Create test suites
  - [ ] Integration testing
  - [ ] Documentation updates

## Notes
- **Critical**: Implement z-score threshold BEFORE sector expansion to prevent API cost explosion
- **Weekly News**: Ensures comprehensive coverage even for commodities not actively queried
- **Cache Strategy**: 7-day window balances freshness with cost efficiency
- **Expected Outcome**: 80-90% reduction in API calls while maintaining full news coverage