# Sector Expansion Plan (Simplified)

**Status:** ✅ COMPLETED
**Created:** January 2025
**Updated:** January 19, 2025 - Implementation complete
**Timeline:** Completed Jan 19, 2025
**Dependencies:** AI-SQL Unified Dashboard (currently active)
**Priority:** 2

## Goal
Simplify the sector expansion implementation by leveraging the existing `Ticker_Reference` table in MSSQL database, which already contains ticker-to-name mappings and sector information, eliminating the need for complex commodity configuration files. Expand from 5 steel commodities to all sectors in the database.

## Key Considerations
- **Database Already Has Mappings**: `Ticker_Reference` table contains Ticker, Name, Sector, Unit columns
- **Simplified Config**: Only need sector → news source mapping, not individual commodity mappings
- **Existing Pattern**: `data_loader.py` already queries the database for commodity lists
- **Dependencies**: MSSQL connection required to fetch commodity metadata
- **Risk Mitigation**: Some sectors (Livestock, Fishery) have ticker mapping issues noted in documentation
- **Scalability**: Automatically supports new commodities added to database without code changes
- **API Costs**: Expanding from 5 to potentially 100+ commodities increases API usage

## Step-by-Step Plan

### Phase 1: Create Sector Configuration
1. Create `current/sql-dashboard/config/news_sources.yaml`:
   - Define sector-to-news-source mappings for all 11 sectors
   - Add query settings (vietnam_focus, cache_duration, etc.)
   - Include authoritative sources per sector:
     * Agricultural: USDA, AgWeb, Reuters Agriculture
     * Energy: EIA, OilPrice.com, Platts
     * Metals: Kitco, MetalBulletin, LME, Mining.com
     * Chemicals: ICIS, ChemWeek
     * Fertilizer: FertilizerPricing, CRU Group
     * Livestock: CattleFax, ThePigSite
     * Shipping_Freight: Baltic Exchange, TradeWinds, Lloyd's List
     * Aviation: IATA, Airline Industry Review
     * Fishery: SeafoodSource, Undercurrent News

### Phase 2: Database Integration
2. Update `modules/data_loader.py`:
   - Add function `get_commodity_metadata()` to fetch from Ticker_Reference table
   - Return dict mapping ticker → {name, sector, unit}
   - Handle NULL names gracefully (use ticker as fallback)

3. Create `modules/ai_integration/sector_config.py`:
   - Load news_sources.yaml configuration
   - Function `get_sector_sources(sector: str) → List[str]`
   - Cache configuration in memory for performance

### Phase 3: Update Query Orchestration
4. Modify `modules/ai_integration/commodity_queries.py`:
   - Replace hardcoded commodity list with database query
   - Use `get_commodity_metadata()` to populate Commodity dataclass
   - Add sector-based filtering support
   - Inject sector sources into commodity definitions

5. Update `modules/ai_integration/perplexity_client.py`:
   - Modify `_build_prompt()` to accept optional source hints
   - Add "Focus on sources like {sector_sources}" to prompt
   - Maintain Vietnam market focus for all queries

### Phase 4: UI Integration
6. Update `current/sql-dashboard/main.py`:
   - Add commodity multi-select filter (populated from database)
   - Show sector grouping in commodity selection
   - Display source attribution in news cards
   - Add "Query Budget" indicator in sidebar

### Phase 5: Testing & Documentation
7. Create `tests/test_sector_expansion.py`:
   - Test database metadata fetching
   - Verify sector source injection
   - Test query generation for each sector
   - Validate cache behavior with expanded commodities

8. Update documentation:
   - Update `.docs/architecture/ai-dashboard-design.md` with new architecture
   - Document configuration structure in README
   - Add examples for extending to new sectors

## Parallelization Opportunities

**Can be done in parallel after Phase 1:**
- Agent 1: Create configuration files (Steps 1-2)
- Agent 2: Update data models (Steps 3-4)
- Agent 3: Implement source guidance (Steps 5-6)
- Agent 4: Update UI components (Step 9)

**Dependencies:**
- Phase 1 must complete first (configuration structure)
- Phase 2-3 can run in parallel
- Phase 4 requires Phase 2-3
- Phase 5-6 can start after Phase 1

## Validation
- **Configuration**: All sectors have at least 3 authoritative sources defined
- **Query Test**: Successfully query 1 commodity from each sector
- **Source Attribution**: Verify Perplexity returns sources from recommended list
- **Cache Performance**: Measure query time with 50+ commodities
- **Cost Projection**: Calculate daily API costs with expanded commodity list
- **UI Functionality**: Sector filtering works, sources displayed correctly

## Implementation Status
- [x] Phase 1: Configuration Structure ✅ (Completed Jan 2025)
  - Created `config/news_sources.yaml` with 11 sectors
  - Added URLs for all news sources
  - Configured Vietnam-specific sources
- [x] Phase 2: Database Integration ✅ (Completed Jan 2025)
  - Added `get_commodity_metadata()` to data_loader.py
  - Returns ticker → {name, sector} mappings
- [x] Phase 3: Update Query Orchestration ✅ (Completed Jan 2025)
  - Created `sector_config.py` module with source management
  - Updated `perplexity_client.py` to accept sector sources
  - Modified `_build_prompt()` to inject source URLs
- [x] Phase 4: Dynamic Commodity Loading ✅ (Completed Jan 19, 2025)
  - Updated `commodity_queries.py` to use database
  - Removed hardcoded 5-commodity list
  - Fixed UTF-8 encoding issue in sector_config.py
  - Fixed singleton pattern for proper config loading
  - Now loads 95 commodities from database dynamically
- [x] Phase 5: UI Updates ✅ (Completed Jan 19, 2025)
  - Added commodity multi-select filter with sector grouping
  - Display source attribution in news cards
  - Dynamic footer showing covered sectors
  - Commodity count display in sidebar
- [x] Phase 6: Testing & Validation ✅ (Completed Jan 19, 2025)
  - Created test scripts for validation
  - Verified all 11 sectors load with sources
  - Confirmed 95 commodities load from database
  - Human-readable names passed to Perplexity API

## Implementation Complete
- Successfully expanded from 5 hardcoded steel commodities to 95 database-driven commodities
- All 11 sectors configured with appropriate news sources and URLs
- Sector-specific news sources guide Perplexity AI to authoritative sources
- Configuration-driven approach allows easy addition of new commodities
- Z-score filtering (threshold: 2.0) manages API costs by only querying volatile commodities
- 24-hour caching reduces redundant API calls