# Developer Documentation Reorganization Plan

**Status:** ⚪ BACKLOG
**Created:** January 2025
**Priority:** Low
**Dependencies:** None
**Note:** Documentation improvements - not blocking main functionality

## Goal
Reorganize scattered documentation into a developer-focused `.docs` directory structure, clearly separating system development documentation from end-user guides, with emphasis on technical implementation details, architecture decisions, and development workflows.

## Key Considerations
- **Developer-first focus**: Prioritize technical documentation over user guides
- **Clear separation**: Flag user-oriented docs for potential removal or minimal inclusion
- **Existing patterns**: Repository already has `.docs/plans/` directory established
- **Migration context**: Documentation reflects ongoing migration (Phase 3 of 7)
- **Multiple dashboards**: Need to document both current implementations and unified architecture
- **Technical debt**: Document known issues, workarounds, and planned improvements

## Step-by-Step Plan

### 1. Audit Current Documentation
- Scan all `.md` files in repository
- Categorize as: Developer/Technical, User/Operations, or Mixed
- Identify duplicates and outdated content
- Flag user-oriented sections for extraction

### 2. Create Developer-Focused Structure
```
/.docs/
├── README.md                        # Developer navigation hub
├── /architecture/                   # System design & decisions
│   ├── system-overview.md          # High-level architecture diagram
│   ├── data-flow.md                # Request/response pipelines
│   ├── caching-architecture.md     # 3-tier cache implementation
│   ├── database-design.md          # Schema, indexes, relationships
│   └── migration-architecture.md   # Unified platform design
│
├── /implementation/                 # Code-level documentation
│   ├── /ai-dashboard/
│   │   ├── perplexity-integration.md
│   │   ├── query-orchestration.md
│   │   └── json-parsing-strategy.md
│   ├── /sql-dashboard/
│   │   ├── mssql-connection-pool.md
│   │   ├── zscore-calculation.md
│   │   └── ag-grid-implementation.md
│   └── /unified/
│       ├── shared-components.md
│       ├── config-loader.md
│       └── feature-modules.md
│
├── /development/                    # Development workflows
│   ├── setup-dev-environment.md    # Developer machine setup
│   ├── coding-standards.md         # From CLAUDE.md
│   ├── git-workflow.md             # Branching, commits
│   ├── testing-strategy.md         # Unit, integration tests
│   ├── debugging-guide.md          # Common issues, tools
│   └── performance-profiling.md    # Optimization techniques
│
├── /api-reference/                 # Technical API docs
│   ├── perplexity-api.md          # Request/response formats
│   ├── internal-apis.md           # Module interfaces
│   ├── database-queries.md        # SQL patterns, optimization
│   └── cache-api.md               # Cache manager interface
│
├── /infrastructure/                # Deployment & DevOps
│   ├── environment-config.md      # Dev/staging/prod setup
│   ├── deployment-pipeline.md     # CI/CD configuration
│   ├── monitoring-logging.md      # Observability setup
│   ├── ssl-certificates.md        # SSL config & issues
│   └── database-migration.md      # SQLite to MSSQL migration
│
├── /plans/                         # Implementation plans (existing)
│   ├── gradual-migration-plan.md  # Current 7-phase plan
│   └── [future plans...]
│
├── /technical-debt/                # Known issues & improvements
│   ├── ssl-workaround.md         # Current SSL cert issue
│   ├── duplicate-code.md         # Code duplication tracker
│   ├── performance-issues.md     # Bottlenecks to address
│   └── refactoring-targets.md    # Planned refactoring
│
├── /decisions/                     # Architecture Decision Records
│   ├── 001-dual-dashboard.md     # Why two dashboards
│   ├── 002-perplexity-choice.md  # Why Perplexity AI
│   ├── 003-caching-strategy.md   # Why 3-tier cache
│   └── 004-unified-platform.md   # Migration rationale
│
└── /user-guides/                  # ⚠️ USER-ORIENTED (minimal)
    ├── quick-start.md             # Basic usage only
    └── troubleshooting-faq.md    # Common user issues
```

### 3. Document Classification & Alerts

**Developer-focused (keep/expand):**
- CLAUDE.md → `/development/coding-standards.md`
- CLAUDE_notes.md → `/architecture/ai-dashboard-design.md`
- Commodity_Database_Schema.md → `/architecture/database-design.md`
- MIGRATION.md → `/plans/repository-migration.md`
- Technical sections of README.md → Various technical docs

**⚠️ USER-ORIENTED (flag for review):**
- Setup instructions for non-developers
- Dashboard usage guides
- Business context sections
- Feature descriptions without technical detail

**Mixed content (needs splitting):**
- Current README.md → Split technical (keep) vs usage (minimize)
- SETUP.md → Split dev setup (keep) vs user setup (minimize)

### 4. Create Navigation & Cross-References
- Generate `.docs/README.md` with developer-focused TOC
- Add "Related docs" section to each document
- Create code-to-docs mapping (which code → which doc)
- Add inline code comments pointing to detailed docs

### 5. Establish Documentation Standards
- Create `.docs/CONTRIBUTING.md` for doc contributions
- Define templates for each doc type
- Set up naming conventions (kebab-case, prefixes)
- Create doc review checklist

### 6. Migration Execution
- Create `.docs/` structure with empty folders
- Move documents in phases:
  1. Architecture & implementation docs
  2. Development workflows
  3. API references
  4. Infrastructure docs
  5. Technical debt tracking
- Update all internal links
- Add redirect notices in old locations
- Update root README.md to point to `.docs/`

## Parallelization Opportunities

**Can be done in parallel:**
- Team A: Move architecture docs + create system diagrams
- Team B: Extract technical content from mixed docs
- Team C: Document technical debt and known issues
- Team D: Create API reference documentation

**Must be sequential:**
1. Create folder structure first
2. Move core documentation
3. Update cross-references
4. Validate all links work

## Validation

**Success criteria:**
- [ ] All `.md` files moved to appropriate `.docs/` subdirectory
- [ ] No broken internal links (automated check)
- [ ] Developer can navigate from code to relevant docs
- [ ] Clear separation of developer vs user content
- [ ] Technical debt is documented and tracked
- [ ] Architecture decisions are recorded
- [ ] All code modules have corresponding implementation docs

**Validation steps:**
1. Run link checker script on all markdown files
2. Grep for old documentation paths in codebase
3. Ensure each major module has documentation
4. Review user-oriented sections are minimal/removed
5. Test documentation navigation flow

## Implementation Status

- **Plan created**: January 17, 2025
- **Status**: Approved and ready for implementation
- **Priority**: Medium (can proceed after Phase 4 of main migration)

---
*This plan prioritizes developer documentation. User-facing documentation is minimized to a single `/user-guides/` folder with only essential content.*