# AI-SQL Unified Dashboard Implementation Plan

**Status:** 🟢 TESTING PHASE (Day 5-6 of 7)
**Created:** January 2025
**Last Updated:** September 2025
**Timeline:** 7 working days
**Dependencies:** AI-MSSQL Migration (✅ Completed)
**Supersedes:** gradual-migration-plan.md

## Current Progress
- ✅ **Phase 1**: Module Migration (Completed)
- ✅ **Phase 2**: Configuration Setup (Completed)
- ✅ **Phase 3**: UI Integration (Completed)
- ❌ **Phase 4**: Data Integration (Removed - not needed per requirements)
- 🔄 **Phase 5**: Testing & Validation (In Progress)
- 📋 **Phase 6**: Documentation & Deployment (Pending)

## Goal
Port AI dashboard functionality into SQL dashboard to create a unified dashboard, maintaining the existing 5 steel commodities initially, then expanding to all database sectors after successful integration.

## Key Considerations
- Both dashboards already share MSSQL database with AI tables created
- Minimize code duplication by reusing existing modules
- ~~Maintain backward compatibility - SQL dashboard must work without AI features~~ **UPDATE**: AI features are now default, not optional
- Start with 5 steel commodities for testing, expand after validation
- Use existing database connection patterns from SQL dashboard
- **NEW**: Write access required for new AI queries (read-only sufficient for cached data)

## Step-by-Step Plan

### Phase 1: Module Migration (Day 1-2)

#### 1. Create AI Integration Directory Structure
```bash
current/sql-dashboard/modules/ai_integration/
├── __init__.py
├── perplexity_client.py
├── commodity_queries.py
├── data_processor.py
└── ai_database.py
```

#### 2. Copy and Adapt Core Modules
- Copy `current/ai-dashboard/src/api/perplexity_client.py` → `modules/ai_integration/`
- Copy `current/ai-dashboard/src/api/commodity_queries.py` → `modules/ai_integration/`
- Copy `current/ai-dashboard/src/processing/data_processor.py` → `modules/ai_integration/`
- Update import paths to reference SQL dashboard structure

#### 3. Create Unified Database Interface
Create `modules/ai_integration/ai_database.py`:
- Import existing `DatabaseConnection` from `modules/db_connection.py`
- Copy AI-specific methods from AI dashboard's `database.py`
- Add method to check for write permissions (DC_DB_STRING_MASTER)
- Implement fallback to read-only if write unavailable

#### 4. Copy Utility Modules
- Copy `rate_limiter.py` → `modules/utils/`
- Copy `error_handler.py` → `modules/utils/`
- Merge logging configs into existing structure

### Phase 2: Configuration Setup (Day 2)

#### 5. Environment Configuration
Create `modules/config.py`:
```python
AI_FEATURES_ENABLED = os.getenv('ENABLE_AI_FEATURES', 'false').lower() == 'true'
PERPLEXITY_API_KEY = os.getenv('PERPLEXITY_API_KEY')
AI_DB_STRING = os.getenv('DC_DB_STRING_MASTER', os.getenv('DC_DB_STRING'))
```

#### 6. Update Requirements
Add to `current/sql-dashboard/requirements.txt`:
- Verify all AI dashboard dependencies included
- Ensure version compatibility

### Phase 3: UI Integration (Day 3-4)

#### 7. Import AI Modules in main.py
After line 8 in `current/sql-dashboard/main.py`:
```python
# AI Integration Imports (optional feature)
try:
    from modules.config import AI_FEATURES_ENABLED, PERPLEXITY_API_KEY
    if AI_FEATURES_ENABLED and PERPLEXITY_API_KEY:
        from modules.ai_integration.perplexity_client import PerplexityClient, TimeFrame
        from modules.ai_integration.commodity_queries import CommodityQueryOrchestrator
        from modules.ai_integration.data_processor import DataProcessor as AIDataProcessor
        from modules.ai_integration.ai_database import AIDatabase
        AI_AVAILABLE = True
    else:
        AI_AVAILABLE = False
except ImportError:
    AI_AVAILABLE = False
```

#### 8. Initialize AI Services
After line 31 (after data loading):
```python
# Initialize AI services if available
if AI_AVAILABLE:
    @st.cache_resource
    def initialize_ai_services():
        client = PerplexityClient()
        ai_db = AIDatabase()
        orchestrator = CommodityQueryOrchestrator(client, ai_db)
        processor = AIDataProcessor()
        return orchestrator, processor, ai_db

    ai_orchestrator, ai_processor, ai_database = initialize_ai_services()
```

#### 9. Add AI Controls to Sidebar
After line 99 (after chart options):
```python
if AI_AVAILABLE:
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 🤖 AI Intelligence")

    ai_timeframe = st.sidebar.radio(
        "AI Analysis Period",
        options=["1 week", "1 month"],
        index=0,
        help="Period for AI market analysis"
    )

    col1, col2 = st.sidebar.columns(2)
    with col1:
        if st.button("🔄 Refresh AI", use_container_width=True):
            st.session_state.ai_refresh = True
    with col2:
        if st.button("🗑️ Clear Cache", use_container_width=True):
            ai_orchestrator.daily_cache.clear()
            st.success("Cache cleared!")

    # Show cache status
    if hasattr(st.session_state, 'ai_last_update'):
        time_diff = datetime.now() - st.session_state.ai_last_update
        st.sidebar.caption(f"AI data: {int(time_diff.total_seconds()/60)}m ago")
```

#### 10. Add AI Data Fetching
After line 130 (after price changes calculation):
```python
# Fetch AI intelligence if available
ai_results = None
ai_table_data = None
ai_news_cards = None

if AI_AVAILABLE:
    # Check if refresh needed
    force_refresh = st.session_state.get('ai_refresh', False)

    # Get cached or fresh AI data
    with st.spinner("🤖 Loading AI intelligence..." if force_refresh else "🤖 Checking AI cache..."):
        ai_results = ai_orchestrator.query_all_commodities(
            timeframe=ai_timeframe,
            force_refresh=force_refresh
        )

        if ai_results:
            ai_table_data, ai_news_cards = ai_processor.process_query_results(ai_results)
            st.session_state.ai_last_update = datetime.now()
            st.session_state.ai_refresh = False
```

#### 11. Insert AI Summary Table
After line 169 (after market metrics):
```python
# AI Intelligence Summary
if AI_AVAILABLE and ai_table_data:
    st.markdown("### 🤖 AI Market Intelligence")

    # Convert to DataFrame for display
    ai_df = pd.DataFrame(ai_table_data)

    # Style the dataframe
    def style_ai_trend(val):
        if "bullish" in str(val).lower():
            return "color: green; font-weight: bold"
        elif "bearish" in str(val).lower():
            return "color: red; font-weight: bold"
        return ""

    styled_ai_df = ai_df.style.applymap(
        style_ai_trend,
        subset=['Trend'] if 'Trend' in ai_df.columns else []
    )

    st.dataframe(styled_ai_df, use_container_width=True, height=250)
```

#### 12. Add News Cards Section
After line 177 (after detailed price table):
```python
# Recent Market News from AI
if AI_AVAILABLE and ai_news_cards:
    st.markdown("### 📰 AI-Curated Market News")

    # Create responsive columns
    news_cols = st.columns(2)

    for idx, card in enumerate(ai_news_cards[:6]):  # Limit to 6 cards
        with news_cols[idx % 2]:
            # Create news card with styling
            st.markdown(f"""
            <div style='
                background: white;
                padding: 1rem;
                border-radius: 8px;
                border-left: 3px solid #00816D;
                margin-bottom: 1rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            '>
                <h4>{card.get('title', 'Market Update')}</h4>
                <p>{card.get('content', '')[:200]}...</p>
                <small>📅 {card.get('timestamp', 'Recent')}</small>
            </div>
            """, unsafe_allow_html=True)
```

### Phase 4: Data Integration (Day 5)

#### 13. Merge AI Intelligence with SQL Data
In `modules/data_loader.py`, add function:
```python
def merge_ai_intelligence(analysis_df, ai_results):
    """Merge AI insights with commodity analysis"""
    if not ai_results:
        return analysis_df

    # Create AI lookup dict
    ai_dict = {
        result['commodity']: {
            'AI_Trend': result.get('data', {}).get('trend', 'unknown'),
            'AI_Confidence': result.get('data', {}).get('confidence_score', 0),
            'AI_Drivers': ', '.join(result.get('data', {}).get('key_drivers', []))
        }
        for result in ai_results if result.get('success')
    }

    # Map natural names to tickers (simplified for steel)
    name_mapping = {
        'iron ore': ['IOECAU62 Index'],
        'coking coal': ['IAC1 COMB Comdty', 'CVCNTLJK AMTL Index'],
        'scrap steel': ['CNMUSHAN Index'],
        'steel rebar': ['Spot VN LS', 'VN LS'],
        'steel HRC': ['HRC1 Comdty', 'Spot VN HRC', 'VN HRC']
    }

    # Add AI columns
    for commodity, tickers in name_mapping.items():
        if commodity in ai_dict:
            for ticker in tickers:
                mask = analysis_df['Ticker'] == ticker
                if mask.any():
                    for key, value in ai_dict[commodity].items():
                        analysis_df.loc[mask, key] = value

    return analysis_df
```

#### 14. Enhance Visualizations with AI
Update chart generation to include AI indicators:
- Add AI trend arrows to price charts
- Color-code performance bars based on AI sentiment
- Add AI confidence scores to tooltips

### Phase 5: Testing & Validation (Day 6)

#### 15. Create Test Suite
Create `tests/test_ai_integration.py`:
- Test AI module imports
- Test database connectivity
- Test cache operations
- Test UI rendering with/without AI
- Test data merging

#### 16. Performance Testing
- Measure page load with AI enabled/disabled
- Verify cache response times <50ms
- Test API response handling
- Monitor database connection pooling

#### 17. Error Handling
- Test with missing API key
- Test with database write failures
- Test with network timeouts
- Verify graceful degradation

### Phase 6: Documentation & Deployment (Day 7)

#### 18. Update Documentation
- Update README with AI feature instructions
- Document environment variables
- Add troubleshooting guide
- Create user guide for new features

#### 19. Create Migration Script
Create `scripts/setup_unified_dashboard.sh`:
```bash
#!/bin/bash
# Check environment variables
# Copy modules
# Update requirements
# Run tests
# Display success message
```

#### 20. Final Validation Checklist
- [ ] SQL dashboard works without AI features
- [ ] AI features activate with proper env vars
- [ ] Cache operations successful
- [ ] UI displays AI data correctly
- [ ] Performance meets targets
- [ ] Documentation complete

## Parallelization Opportunities

**Can be done in parallel after Phase 1:**
- **Agent 1**: UI integration (Steps 7-12)
- **Agent 2**: Data integration (Steps 13-14)
- **Agent 3**: Testing suite (Steps 15-17)
- **Agent 4**: Documentation (Steps 18-19)

## Success Metrics
- Page load time <2s with AI enabled
- Cache hit rate >80% after first load
- Zero breaking changes to SQL dashboard
- All 5 steel commodities show AI data
- News cards display with proper formatting

## Next Steps After Completion
1. Monitor for 1 week with 5 commodities
2. Gather user feedback
3. Implement commodity expansion plan
4. Add sector-specific configurations
5. Scale to 100+ commodities

## Timeline
- **Day 1-2**: Module Migration
- **Day 2**: Configuration Setup
- **Day 3-4**: UI Integration
- **Day 5**: Data Integration
- **Day 6**: Testing & Validation
- **Day 7**: Documentation & Deployment

Total estimated time: 7 working days for full implementation

## Risk Mitigation
1. **Database Permissions**: Test write access early, fallback to read-only
2. **API Key Management**: Clear error messages if key missing
3. **Performance Impact**: Implement async loading where possible
4. ~~**UI Breakage**: Feature flag to disable AI components~~ **CHANGED**: AI is now default
5. **Cache Issues**: Manual cache clear option in UI

## Dependencies
- MSSQL database with AI tables created
- Perplexity API key (REQUIRED - not optional)
- DC_DB_STRING_MASTER for write operations
- Python packages from AI dashboard requirements

## Implementation Notes (September 2025)

### Key Changes Made
1. **AI Features Default**: Removed optional AI feature flags - AI is now integral to unified dashboard
2. **Write Access Flow**: Implemented 3-tier access check (tables exist → read access → write access)
3. **Database Methods**: Fixed `DatabaseConnection` usage - use `engine.connect()` not `get_connection()`
4. **Warning Fixes**: Resolved FutureWarnings for pandas operations (`applymap` → `map`, downcasting fixes)

### Issues Encountered & Resolved

#### 1. Database Connection Method Error
**Problem**: `'DatabaseConnection' object has no attribute 'get_connection'`
**Solution**: Use `self.db.engine.connect()` instead of `self.db.get_connection()`

#### 2. Write Access Detection
**Problem**: System blocked all operations when no write access, even reading cache
**Solution**: Implemented granular access levels:
- Read-only: Can use existing cache
- Write: Can query new data from Perplexity API
- Only block API queries if no cache AND no write access

#### 3. Column Name Mismatches
**Problem**: Code used incorrect column names (e.g., `CommodityName` instead of `Commodity`)
**Solution**: Updated all queries to match actual database schema from documentation

#### 4. Pandas Deprecation Warnings
**Problem**: Multiple FutureWarnings for `.ffill()`, `.applymap()` operations
**Solution**:
- Added `.astype('float64')` for proper dtype handling
- Replaced `applymap()` with `map()` for Styler objects
- Used `np.nan` instead of `pd.NA` for compatibility

### Current Architecture

```
User Request → Check Cache (read-only OK)
                ↓ (if cache miss)
           Check Write Access
                ↓ (if has write)
           Query Perplexity API
                ↓
           Save to Database
                ↓
           Display Results
```

### Access Requirements

| Action | Required Access | Fallback |
|--------|----------------|----------|
| View cached AI data | Read | No AI features |
| Refresh AI data | Write | Show warning |
| Clear cache | Write | Button disabled |
| Initial AI query | Write | Use cache only |

---
*Generated: January 2025*
*Last Updated: September 2025*
*Status: Testing Phase - Core implementation complete*