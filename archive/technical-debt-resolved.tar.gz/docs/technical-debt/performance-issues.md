# Performance Issues

## Overview
This document tracks known performance bottlenecks and optimization opportunities in the Commodity AI Dashboard system.

## Resolved Performance Issues

### 1. AI Intelligence Blocking Dashboard Load [RESOLVED - Jan 2025]

#### Previous Issue
The AI intelligence feature blocked the entire dashboard from rendering while fetching data, causing 10-25 second delays before users could see any content.

#### Solution Implemented
- Separated AI intelligence into an independent Streamlit fragment (`modules/ai_section.py`)
- Used `@st.fragment` decorator to enable async loading
- Main dashboard renders immediately while AI loads in background

#### Implementation Details
```python
# New modular approach in modules/ai_section.py
@st.fragment
def render_ai_intelligence_section(...):
    # AI data loads independently
    with st.spinner("🤖 Loading AI intelligence..."):
        ai_results = ai_orchestrator.query_all_commodities(...)

# Main.py now calls the fragment
render_ai_intelligence_section(
    ai_orchestrator=ai_orchestrator,
    ai_processor=ai_processor,
    ...
)
```

#### Results
- **Initial render time**: < 2 seconds (from 10-25s)
- **User can interact** with dashboard while AI loads
- **Progressive enhancement**: AI content appears when ready
- **No blocking**: Main charts, tables, and filters work immediately

#### Impact: CRITICAL performance improvement for user experience

## Critical Performance Issues

### 1. Sequential API Calls

#### Issue
The AI dashboard queries commodities sequentially rather than in parallel.

#### Current Implementation
```python
# In commodity_queries.py
results = []
for commodity in commodities:
    result = query_perplexity(commodity)  # 2-5s each
    results.append(result)
# Total time: 10-25s for 5 commodities
```

#### Impact
- **Load time**: 10-25 seconds for 5 commodities
- **User experience**: Long wait on dashboard refresh
- **API efficiency**: Not utilizing available rate limit capacity

#### Proposed Solution
```python
from concurrent.futures import ThreadPoolExecutor

def parallel_query(commodities):
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(query_perplexity, c) for c in commodities]
        results = [f.result() for f in futures]
    return results
# Total time: 2-5s (parallel)
```

#### Priority: HIGH

### 2. Large DataFrame Operations

#### Issue
SQL dashboard loads entire commodity history into memory.

#### Current Code
```python
# In data_loader.py
def load_all_data():
    query = "SELECT * FROM Steel"  # 50,000+ rows
    df = pd.read_sql(query, conn)
    return df  # ~100MB in memory
```

#### Impact
- **Memory usage**: 100-500MB per user session
- **Initial load**: 5-10 seconds
- **Scalability**: Memory issues with multiple users

#### Proposed Solution
```python
def load_data_chunked(chunk_size=1000):
    query = "SELECT * FROM Steel WHERE Date > ?"
    date_limit = datetime.now() - timedelta(days=90)

    for chunk in pd.read_sql(query, conn, params=[date_limit], chunksize=chunk_size):
        yield process_chunk(chunk)
```

#### Priority: MEDIUM

### 3. Inefficient Z-Score Calculations

#### Issue
Z-scores recalculated on every dashboard refresh for all commodities.

#### Current Implementation
```python
# Recalculates entire history every time
def calculate_all_zscores(df):
    for commodity in df['Ticker'].unique():
        subset = df[df['Ticker'] == commodity]
        df.loc[df['Ticker'] == commodity, 'zscore'] = calculate_zscore(subset)
    return df
```

#### Impact
- **CPU usage**: High on every refresh
- **Response time**: 2-3 second delay
- **Redundant computation**: Same data recalculated

#### Proposed Solution
```python
from functools import lru_cache

@lru_cache(maxsize=128)
def get_cached_zscore(commodity: str, date: str) -> float:
    """Cache Z-score calculations"""
    return calculate_zscore(commodity, date)

# Or use database persistence
def store_calculated_zscores():
    """Pre-calculate and store in database"""
    INSERT INTO zscore_cache (commodity, date, zscore)
    VALUES (?, ?, ?)
```

#### Priority: MEDIUM

### 4. Streamlit Session State Bloat

#### Issue
Session state grows unbounded with cached data.

#### Current Behavior
```python
# Cache never expires or clears
st.session_state.cache[key] = large_dataframe  # Keeps growing
```

#### Impact
- **Memory leak**: Session state can grow to 1GB+
- **Browser performance**: Slow UI interactions
- **Server resources**: High memory per session

#### Proposed Solution
```python
class BoundedCache:
    def __init__(self, max_size=100, max_age_minutes=30):
        self.cache = {}
        self.max_size = max_size
        self.max_age = timedelta(minutes=max_age_minutes)

    def set(self, key, value):
        # Remove oldest if at capacity
        if len(self.cache) >= self.max_size:
            oldest = min(self.cache.items(), key=lambda x: x[1]['time'])
            del self.cache[oldest[0]]

        self.cache[key] = {
            'value': value,
            'time': datetime.now()
        }

    def get(self, key):
        if key in self.cache:
            entry = self.cache[key]
            if datetime.now() - entry['time'] < self.max_age:
                return entry['value']
            del self.cache[key]
        return None
```

#### Priority: HIGH

### 5. Database Query Optimization

#### Issue
Missing indexes and inefficient queries in SQL Server.

#### Problem Queries
```sql
-- No index on Date column
SELECT * FROM Steel WHERE Date > '2024-01-01'

-- No pagination
SELECT * FROM Agricultural ORDER BY Date DESC

-- Multiple separate queries instead of JOIN
SELECT * FROM Steel WHERE Ticker = 'IRON_ORE'
SELECT * FROM Metals WHERE Ticker = 'COPPER'
```

#### Impact
- **Query time**: 2-5 seconds for large tables
- **Database load**: High CPU on SQL Server
- **Network traffic**: Large result sets transferred

#### Proposed Solution
```sql
-- Add indexes
CREATE INDEX idx_steel_date ON Steel(Date);
CREATE INDEX idx_steel_ticker_date ON Steel(Ticker, Date);

-- Use pagination
SELECT * FROM Agricultural
ORDER BY Date DESC
OFFSET 0 ROWS FETCH NEXT 100 ROWS ONLY;

-- Combine queries with UNION
SELECT 'Steel' as Source, * FROM Steel WHERE Ticker = ?
UNION ALL
SELECT 'Metals' as Source, * FROM Metals WHERE Ticker = ?
```

#### Priority: HIGH

## Performance Metrics

### Current Performance
| Operation | Current Time | Target Time | Improvement | Status |
|-----------|-------------|-------------|-------------|---------|
| Initial Load | ~~10-25s~~ **<2s** | 2-5s | ✅ 90% | **RESOLVED** |
| Refresh Data | 5-10s | 1-2s | 80% | Pending |
| Z-Score Calc | 2-3s | <0.5s | 85% | Pending |
| Database Query | 2-5s | <1s | 75% | Pending |
| Memory Usage | 500MB/user | 100MB/user | 80% | Pending |

### Bottleneck Analysis
```
Total Load Time: 15s
├── API Calls: 10s (66%) <- MAIN BOTTLENECK
├── Database: 3s (20%)
├── Processing: 1.5s (10%)
└── Rendering: 0.5s (4%)
```

## Quick Wins

### 1. Enable Streamlit Caching
```python
@st.cache_data(ttl=3600)
def expensive_operation(param):
    return result
```

### 2. Lazy Loading
```python
# Load data only when tab is selected
if current_tab == "Analysis":
    data = load_analysis_data()
```

### 3. Reduce DataFrame Copies
```python
# Avoid
df_copy = df.copy()
df_copy['new_col'] = values

# Better
df['new_col'] = values  # Modify in place when safe
```

### 4. Use Query Projection
```python
# Don't select all columns
# Bad: SELECT * FROM table
# Good: SELECT ticker, date, price FROM table
```

## Monitoring Implementation

### Performance Logging
```python
import time
from functools import wraps

def measure_performance(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        duration = time.perf_counter() - start

        if duration > 1.0:  # Log slow operations
            logger.warning(f"{func.__name__} took {duration:.2f}s")

        # Store metrics
        metrics.record(func.__name__, duration)
        return result
    return wrapper
```

### Profiling Script
```python
import cProfile
import pstats

def profile_dashboard():
    profiler = cProfile.Profile()
    profiler.enable()

    # Run dashboard operations
    load_dashboard()
    refresh_data()
    calculate_metrics()

    profiler.disable()
    stats = pstats.Stats(profiler)
    stats.sort_stats('cumulative')
    stats.print_stats(20)  # Top 20 slow functions
```

## Resolution Plan

### Phase 1: Quick Wins (1 day)
- [ ] Add Streamlit caching decorators
- [ ] Implement lazy loading
- [ ] Optimize DataFrame operations

### Phase 2: API Optimization (2 days)
- [ ] Implement parallel API calls
- [ ] Add request pooling
- [ ] Optimize rate limiting

### Phase 3: Database Optimization (2 days)
- [ ] Add missing indexes
- [ ] Optimize queries
- [ ] Implement query caching

### Phase 4: Memory Management (1 day)
- [ ] Implement bounded cache
- [ ] Add cache expiration
- [ ] Reduce DataFrame memory usage

### Phase 5: Monitoring (1 day)
- [ ] Add performance logging
- [ ] Create performance dashboard
- [ ] Set up alerts for slow operations

## Testing Performance Improvements

### Load Testing
```bash
# Using locust
locust -f tests/load_test.py --host=http://localhost:8501

# Simple concurrent test
for i in {1..10}; do
    curl http://localhost:8501 &
done
```

### Memory Profiling
```python
from memory_profiler import profile

@profile
def memory_intensive_function():
    # Function to profile
    pass
```

## Success Metrics

- **Page Load**: < 3 seconds (from 15s)
- **Refresh Time**: < 2 seconds (from 10s)
- **Memory Usage**: < 200MB per user (from 500MB)
- **CPU Usage**: < 30% average (from 60%)
- **Concurrent Users**: Support 50+ (from 10)

## Tracking

- **Created**: January 2025
- **Priority**: HIGH
- **Target Resolution**: Phase 4-5 of migration
- **Estimated Effort**: 1 week
- **Business Impact**: Direct user experience improvement

## References

- [Streamlit Performance](https://docs.streamlit.io/library/advanced-features/caching)
- [Pandas Optimization](https://pandas.pydata.org/docs/user_guide/enhancingperf.html)
- [SQL Server Performance](https://docs.microsoft.com/en-us/sql/relational-databases/performance/performance-center)
- [Python Profiling](https://docs.python.org/3/library/profile.html)