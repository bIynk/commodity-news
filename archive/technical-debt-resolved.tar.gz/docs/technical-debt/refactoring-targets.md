# Refactoring Targets

## Overview
This document identifies code that needs refactoring to improve maintainability, readability, and adherence to best practices.

## High Priority Refactoring

### 1. Monolithic Dashboard Files

#### Current State
Both `current/ai-dashboard/main.py` and `current/sql-dashboard/main.py` are large monolithic files with 500+ lines.

#### Issues
- Difficult to test individual components
- Hard to maintain and debug
- Violates single responsibility principle

#### Proposed Structure
```
/dashboard/
├── main.py                 # Entry point only
├── components/
│   ├── __init__.py
│   ├── sidebar.py         # Sidebar component
│   ├── metrics.py         # KPI metrics display
│   ├── data_table.py      # Main data table
│   └── charts.py          # Visualization components
├── pages/
│   ├── __init__.py
│   ├── overview.py        # Overview page
│   └── analysis.py        # Analysis page
└── utils/
    ├── __init__.py
    └── formatters.py      # Display formatters
```

#### Refactoring Steps
1. Extract UI components into separate modules
2. Create page modules for different views
3. Separate business logic from presentation
4. Add unit tests for each component

### 2. Magic Numbers and Hardcoded Values ✅ PARTIALLY RESOLVED

#### Status: Staleness thresholds moved to constants module

#### Completed
```python
# Created modules/constants.py with:
class DataFreshnessConfig:
    DAILY_STALENESS_DAYS = 7      # Daily commodities stale after 7 days
    WEEKLY_STALENESS_DAYS = 14    # Weekly commodities stale after 14 days
    FREQUENCY_LOOKBACK_DAYS = 90  # Look at 90 days to detect frequency
    DAILY_THRESHOLD = 0.5         # >50% non-zero returns = daily

# Now properly used in calculations.py for frequency-aware staleness
```

#### Remaining Issues
```python
# Still found in other areas:
@st.cache_data(ttl=43200)  # Magic number: 12 hours in seconds

for i in range(30):  # Magic number in loops
    process_day(i)
```

#### Next Steps
```python
# Add to constants:
class CacheConfig:
    CACHE_TTL_HOURS = 12
    CACHE_TTL_SECONDS = CACHE_TTL_HOURS * 3600

class ProcessingConfig:
    DEFAULT_LOOKBACK_DAYS = 30
```

### 3. Error Handling Inconsistency

#### Current Patterns
```python
# Pattern 1: Silent failure
try:
    result = api_call()
except:
    result = None

# Pattern 2: Generic exception
try:
    data = process()
except Exception as e:
    print(f"Error: {e}")

# Pattern 3: No error handling
data = dangerous_operation()  # Can crash
```

#### Unified Approach
```python
# Create custom exceptions
class CommodityAPIError(Exception):
    """Base exception for API errors"""
    pass

class DataProcessingError(Exception):
    """Base exception for data processing errors"""
    pass

# Consistent error handling
def safe_api_call(commodity: str) -> Dict:
    try:
        return api.query(commodity)
    except requests.Timeout:
        raise CommodityAPIError(f"Timeout querying {commodity}")
    except requests.HTTPError as e:
        raise CommodityAPIError(f"HTTP error {e.response.status_code}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise CommodityAPIError(f"Failed to query {commodity}")
```

### 4. Database Access Layer

#### Current State
SQL queries scattered throughout the codebase with direct database access.

#### Issues
```python
# In various files
conn = pyodbc.connect(connection_string)
cursor = conn.cursor()
cursor.execute("SELECT * FROM Steel")  # Raw SQL everywhere

# No connection pooling
# No query optimization
# SQL injection risks
```

#### Proposed Repository Pattern
```python
# repository/base.py
from abc import ABC, abstractmethod

class Repository(ABC):
    @abstractmethod
    def find_by_id(self, id: str):
        pass

    @abstractmethod
    def find_all(self, filters: Dict = None):
        pass

# repository/commodity.py
class CommodityRepository(Repository):
    def __init__(self, db_connection):
        self.db = db_connection

    def find_by_ticker(self, ticker: str) -> pd.DataFrame:
        query = """
            SELECT Date, Price, Ticker
            FROM Steel
            WHERE Ticker = ?
            ORDER BY Date DESC
        """
        return pd.read_sql_query(query, self.db.conn, params=[ticker])

    def find_recent(self, days: int = 30) -> pd.DataFrame:
        query = """
            SELECT *
            FROM Steel
            WHERE Date >= DATEADD(day, ?, GETDATE())
        """
        return pd.read_sql_query(query, self.db.conn, params=[-days])
```

### 5. Configuration Management

#### Current Issues
- Configuration scattered across files
- Environment-specific settings hardcoded
- No validation of config values

#### Proposed Configuration System
```python
# config/base.py
from pydantic import BaseSettings, validator

class Settings(BaseSettings):
    """Application settings with validation"""

    # API Settings
    perplexity_api_key: str
    api_timeout: int = 30
    max_retries: int = 3

    # Database Settings
    database_url: str
    pool_size: int = 5

    # Cache Settings
    cache_ttl: int = 3600
    cache_enabled: bool = True

    @validator('api_timeout')
    def timeout_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Timeout must be positive')
        return v

    class Config:
        env_file = '.env'
        env_file_encoding = 'utf-8'

# Usage
from config.base import Settings

settings = Settings()
client = APIClient(timeout=settings.api_timeout)
```

## Medium Priority Refactoring

### 6. Duplicate Utility Functions

#### Current State
Same utility functions implemented multiple times:
- `format_price()` in 3 files
- `calculate_percentage()` in 4 files
- `safe_divide()` in 2 files

#### Solution
Create unified utility module:
```python
# utils/calculations.py
def calculate_percentage_change(old: float, new: float) -> float:
    """Calculate percentage change with safety checks"""
    if old == 0:
        return 0 if new == 0 else float('inf')
    return ((new - old) / old) * 100

# utils/formatters.py
def format_currency(value: float, currency: str = 'USD') -> str:
    """Format value as currency"""
    symbols = {'USD': '$', 'EUR': '€', 'GBP': '£'}
    symbol = symbols.get(currency, currency)
    return f"{symbol}{value:,.2f}"
```

### 7. Test Coverage Gaps

#### Current Coverage
- API clients: 20% coverage
- Database operations: 0% coverage
- UI components: 0% coverage
- Utility functions: 40% coverage

#### Target Coverage
- Critical paths: 90% coverage
- Utilities: 100% coverage
- API/Database: 80% coverage

#### Test Structure
```python
# tests/unit/test_api_client.py
import pytest
from unittest.mock import Mock, patch

class TestPerplexityClient:
    @pytest.fixture
    def client(self):
        return PerplexityClient(api_key="test_key")

    def test_query_commodity_success(self, client):
        # Arrange
        with patch('requests.post') as mock_post:
            mock_post.return_value.json.return_value = {...}

            # Act
            result = client.query_commodity("iron ore", "1 week")

            # Assert
            assert result["commodity"] == "iron ore"
            mock_post.assert_called_once()
```

## Low Priority Refactoring

### 8. Code Comments and Documentation

#### Issues
- Missing docstrings
- Outdated comments
- No type hints in older code

#### Standards to Apply
```python
# Before
def calc(x, y):
    # calculates something
    return x * y / 100

# After
def calculate_percentage(base: float, percentage: float) -> float:
    """Calculate percentage of base value.

    Args:
        base: The base value
        percentage: The percentage to calculate

    Returns:
        The calculated percentage value

    Example:
        >>> calculate_percentage(100, 15)
        15.0
    """
    return base * percentage / 100
```

### 9. Import Organization

#### Current State
```python
# Inconsistent import ordering
from datetime import datetime
import sys
import pandas as pd
from .utils import *
import os
from typing import Dict
```

#### Standard Format
```python
# Standard library imports
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional

# Third-party imports
import pandas as pd
import numpy as np
import streamlit as st

# Local application imports
from src.api.client import APIClient
from src.utils.formatters import format_currency
from src.config import settings
```

## Refactoring Checklist

### Before Refactoring
- [ ] Identify all affected code
- [ ] Write tests for current behavior
- [ ] Document current functionality
- [ ] Create feature branch

### During Refactoring
- [ ] Make small, incremental changes
- [ ] Run tests after each change
- [ ] Keep commits atomic and descriptive
- [ ] Update documentation as you go

### After Refactoring
- [ ] All tests passing
- [ ] Code review completed
- [ ] Documentation updated
- [ ] Performance verified
- [ ] No functionality regression

## Metrics for Success

### Code Quality Metrics
- **Cyclomatic Complexity**: < 10 per function
- **Function Length**: < 50 lines
- **File Length**: < 500 lines
- **Test Coverage**: > 80%
- **Code Duplication**: < 5%

### Maintainability Index
- **Current**: 45/100 (Poor)
- **Target**: 75/100 (Good)

## Implementation Priority

1. **Week 1**: Database access layer (High impact)
2. **Week 2**: Error handling standardization
3. **Week 3**: Configuration management
4. **Week 4**: Component extraction
5. **Week 5**: Test coverage improvement

## Tools for Refactoring

### Code Quality Tools
```bash
# Complexity analysis
radon cc src/ -s -nb

# Maintainability index
radon mi src/

# Code duplication
pylint --duplicate-code src/

# Type checking
mypy src/
```

### Automated Refactoring
```bash
# Auto-format code
black src/

# Sort imports
isort src/

# Remove unused imports
autoflake --remove-all-unused-imports -i src/**/*.py
```

## Tracking

- **Created**: January 2025
- **Priority**: MEDIUM
- **Timeline**: 4-6 weeks
- **Effort**: 3-4 developers
- **ROI**: High (reduces maintenance cost by 40%)

## References

- [Martin Fowler's Refactoring](https://refactoring.com/)
- [Clean Code by Robert Martin](https://www.amazon.com/Clean-Code-Handbook-Software-Craftsmanship/dp/0132350882)
- [Python Refactoring Toolkit](https://github.com/python-rope/rope)