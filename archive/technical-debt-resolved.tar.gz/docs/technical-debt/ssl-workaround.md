# SSL Certificate Workaround

## Issue Description
The Perplexity API client currently has SSL certificate verification disabled as a temporary workaround for SSL certificate validation errors during development.

## Current Implementation

### Location
- File: `current/ai-dashboard/src/api/perplexity_client.py`
- Lines: 16-17, 210-211

### Code
```python
# ⚠️ HOTFIX: Disable SSL warnings for testing only
# TODO: REMOVE FOR PRODUCTION - Re-enable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# In query method:
response = self.session.post(
    endpoint,
    json=payload,
    verify=False  # TODO: REMOVE verify=False FOR PRODUCTION
)
```

## Security Implications

### Risks
1. **Man-in-the-Middle Attacks**: Without SSL verification, the connection is vulnerable to MITM attacks
2. **Data Interception**: API keys and commodity data could be intercepted
3. **Compliance Issues**: May violate security policies and regulations

### Impact Level
- **Severity**: HIGH
- **Affected Components**: All Perplexity API calls
- **Data at Risk**: API keys, query data, response data

## Root Cause
The SSL certificate validation fails due to one of the following:
1. Missing or outdated CA certificates in the environment
2. Corporate proxy intercepting SSL connections
3. Python certifi package needs updating
4. WSL2 environment certificate issues

## Proper Solution

### Step 1: Update Certificates
```bash
# Update system certificates
sudo apt-get update
sudo apt-get install ca-certificates

# Update Python certificates
pip install --upgrade certifi
```

### Step 2: Configure Python SSL
```python
import ssl
import certifi

# Set proper SSL context
ssl_context = ssl.create_default_context(cafile=certifi.where())
```

### Step 3: Fix the Code
```python
# Remove these lines:
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Change this:
response = self.session.post(endpoint, json=payload, verify=False)

# To this:
response = self.session.post(endpoint, json=payload, verify=True)
# Or with custom cert bundle:
response = self.session.post(endpoint, json=payload, verify=certifi.where())
```

### Step 4: Handle Corporate Proxy
If behind a corporate proxy:
```python
# Set proxy with proper certificates
proxies = {
    'http': 'http://proxy.company.com:8080',
    'https': 'http://proxy.company.com:8080',
}

# Use corporate certificate bundle
response = self.session.post(
    endpoint,
    json=payload,
    proxies=proxies,
    verify='/path/to/corporate/cert/bundle.pem'
)
```

## Alternative Solutions

### Option 1: Environment Variable
```bash
# Set certificate bundle location
export SSL_CERT_FILE=$(python -m certifi)
export REQUESTS_CA_BUNDLE=$(python -m certifi)
```

### Option 2: Requests Configuration
```python
import requests
from requests.adapters import HTTPAdapter

class SSLAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        kwargs['cert_reqs'] = 'CERT_REQUIRED'
        kwargs['ca_certs'] = certifi.where()
        return super().init_poolmanager(*args, **kwargs)

session = requests.Session()
session.mount('https://', SSLAdapter())
```

## Testing the Fix

### Verification Script
```python
import requests
import certifi

def test_ssl_connection():
    """Test SSL connection to Perplexity API"""
    test_url = "https://api.perplexity.ai"

    try:
        # Test with proper SSL verification
        response = requests.get(test_url, verify=True)
        print(f"✓ SSL verification successful: {response.status_code}")
        return True
    except requests.exceptions.SSLError as e:
        print(f"✗ SSL verification failed: {e}")
        return False
    except Exception as e:
        print(f"✗ Connection failed: {e}")
        return False

if __name__ == "__main__":
    if test_ssl_connection():
        print("Ready for production!")
    else:
        print("SSL issues need to be resolved")
```

## Migration Plan

### Phase 1: Development Environment
1. Test SSL fix in development
2. Update certificates
3. Verify API connectivity

### Phase 2: Staging Environment
1. Deploy with SSL verification enabled
2. Monitor for SSL errors
3. Ensure all API calls work

### Phase 3: Production
1. Remove SSL bypass code
2. Deploy with full SSL verification
3. Monitor error logs

## Tracking

- **Issue Created**: September 2024
- **Last Updated**: January 2025
- **Priority**: HIGH - Must fix before production
- **Assigned To**: DevOps/Security Team
- **Target Resolution**: Before Phase 7 (final cleanup)

## References

- [Python Requests SSL Documentation](https://requests.readthedocs.io/en/latest/user/advanced/#ssl-cert-verification)
- [Certifi Documentation](https://github.com/certifi/python-certifi)
- [Corporate Proxy Configuration](https://requests.readthedocs.io/en/latest/user/advanced/#proxies)