# Code Duplication Tracker

**STATUS: 🟡 IN PROGRESS - Being resolved through unified dashboard implementation**

## Overview
This document tracks code duplication across the repository. The unified dashboard implementation (currently active) will eliminate most duplication by consolidating the two dashboards into a single codebase.

## Major Duplications

### 1. Dashboard Entry Points

#### Duplication
- `app.py` (moved to legacy)
- `current/ai-dashboard/main.py`
- Both files are identical

#### Impact
- Maintenance burden: Changes need to be made in multiple places
- Confusion: Unclear which file is the source of truth

#### Resolution
- Remove legacy files after Phase 7
- Use only `current/ai-dashboard/main.py`

### 2. Database Connection Logic

#### Duplication
Multiple implementations of database connection:
- `current/ai-dashboard/src/storage/database.py` - SQLite implementation
- `current/ai-dashboard/src/storage/mssql_database.py` - MSSQL implementation
- `current/sql-dashboard/modules/db_connection.py` - MSSQL implementation
- `unified/shared/database/base_adapter.py` - Abstract base (new)

#### Code Example
```python
# In ai-dashboard/src/storage/database.py
def get_connection(self):
    return sqlite3.connect(self.db_path)

# In sql-dashboard/modules/db_connection.py
def get_connection(self):
    return pyodbc.connect(self.connection_string)

# Both doing the same thing with different databases
```

#### Impact
- Different error handling approaches
- Inconsistent connection pooling
- Difficult to maintain

#### Resolution
- Migrate to unified database adapter pattern
- Use `unified/shared/database/` implementations
- Single connection interface for both databases

### 3. Caching Implementation

#### Duplication
Cache logic exists in multiple places:
- `current/ai-dashboard/src/api/commodity_queries.py` - 3-tier cache
- `current/sql-dashboard/modules/data_loader.py` - Simple cache
- `unified/shared/cache/cache_manager.py` - Unified cache (new)

#### Code Comparison
```python
# AI Dashboard cache
def check_cache(commodity, date):
    # Check memory
    if commodity in st.session_state.cache:
        return st.session_state.cache[commodity]
    # Check database
    return db.get_cached_data(commodity, date)

# SQL Dashboard cache
def check_cache(key):
    if key in cache_dict:
        return cache_dict[key]
    return None

# Similar pattern, different implementations
```

#### Resolution
- Consolidate to unified cache manager
- Single caching strategy for both dashboards
- Consistent TTL and invalidation

### 4. Data Processing Functions

#### Duplication
Data formatting repeated across dashboards:
- `current/ai-dashboard/src/processing/data_processor.py`
- `current/sql-dashboard/modules/calculations.py`

#### Examples
```python
# Both have price formatting
def format_price(value):  # AI dashboard
    return f"${value:,.2f}"

def format_currency(value):  # SQL dashboard
    return f"${value:,.2f}"

# Both calculate percentage changes
def calculate_change(old, new):  # AI dashboard
    return ((new - old) / old) * 100

def percent_change(before, after):  # SQL dashboard
    return ((after - before) / before) * 100
```

#### Resolution
- Create shared utility module
- Standardize function names
- Move to `unified/shared/utils/`

### 5. Configuration Loading

#### Duplication
- `config.yaml` at root
- `current/ai-dashboard/config.yaml` (copy)
- `unified/config/base_config.yaml` (new structure)

#### Impact
- Configuration drift
- Unclear which config is authoritative
- Settings inconsistencies

#### Resolution
- Single configuration source
- Environment-based overrides
- Use unified config loader

## File-Level Duplications

### Complete File Duplicates
| Original | Duplicate | Status |
|----------|-----------|---------|
| `app.py` | `legacy/ai-dashboard-original/app.py` | To be removed |
| `/src/*` | `legacy/ai-dashboard-original/src/*` | To be removed |
| `Commodities-Dashboard-v2/*` | `legacy/sql-dashboard-original/*` | To be removed |

### Partial Duplicates
| File 1 | File 2 | Overlap | Action |
|--------|--------|---------|--------|
| AI dashboard README | SQL dashboard README | Setup instructions | Consolidate |
| `perplexity_client.py` | Legacy copy | 100% | Remove legacy |
| Various `__init__.py` | Multiple locations | Boilerplate | Standardize |

## Code Smell Patterns

### 1. Copy-Paste Programming
```python
# Found in 3 different files:
def safe_divide(a, b):
    if b == 0:
        return 0
    return a / b
```

### 2. Similar But Not Identical
```python
# Version 1
def fetch_data(commodity):
    data = db.query(f"SELECT * FROM {commodity}")
    return process(data)

# Version 2
def get_commodity_data(commodity_name):
    result = database.execute(f"SELECT * FROM {commodity_name}")
    return format_data(result)

# Same logic, different names
```

### 3. Dead Code
- Commented out functions still present
- Old implementations kept "just in case"
- Unused imports across files

## Metrics

### Duplication Statistics
- **Total duplicate lines**: ~2,500 lines
- **Duplicate files**: 15+ files
- **Duplicate functions**: 30+ functions
- **Maintenance overhead**: 40% extra effort

### Impact Assessment
- **High Impact**: Database connections, caching
- **Medium Impact**: Utility functions, formatting
- **Low Impact**: Boilerplate, imports

## Resolution Plan

### UPDATE: Unified Dashboard Implementation (ACTIVE)
The unified dashboard implementation will resolve most duplication issues:
- **Timeline**: 7-day implementation plan in progress
- **Approach**: Port AI features into SQL dashboard as optional modules
- **Result**: Single codebase with shared components

### Phase 1: Identify and Document ✅ COMPLETE
- [x] Scan for duplicates
- [x] Document in this file
- [x] Assess impact

### Phase 2: Unified Dashboard Implementation 🟡 IN PROGRESS
- [x] Plan created (ai-sql-unified-implementation-plan.md)
- [ ] Module migration (Day 1-2)
- [ ] UI integration (Day 3-4)
- [ ] Data merging (Day 5)
- [ ] Testing (Day 6)
- [ ] Documentation (Day 7)

### Phase 3: Code Consolidation (NEXT)
- [ ] Remove AI dashboard after unified dashboard complete
- [ ] Delete legacy directories
- [ ] Clean up duplicate utilities
- [ ] Standardize shared functions

### Phase 4: Prevention Measures
- [ ] Code review guidelines requiring DRY
- [ ] Shared component library enforced
- [ ] Documentation on using unified modules

## Tools for Detection

### Using pylint
```bash
pylint --duplicate-code --min-similarity-lines=10 src/
```

### Using jscpd
```bash
npm install -g jscpd
jscpd --min-lines 5 --min-tokens 50 src/
```

### Manual Review
```bash
# Find similar function names
grep -r "^def " --include="*.py" | sort | uniq -d

# Find identical files
fdupes -r .
```

## Priority Items

1. **SSL workaround code** - Duplicated in legacy
2. **Database connections** - Multiple implementations
3. **Cache logic** - Three different approaches
4. **Configuration files** - Multiple copies
5. **Utility functions** - Scattered everywhere

## Tracking

- **Created**: January 2025
- **Last Updated**: January 2025 (Updated with unified dashboard status)
- **Target Resolution**: Will be resolved by unified dashboard (7-day plan)
- **Estimated Effort**: Included in unified dashboard implementation
- **Priority**: HIGH (being actively resolved)
- **Status**: 🟡 IN PROGRESS - Resolution through unification

## References

- [DRY Principle](https://en.wikipedia.org/wiki/Don%27t_repeat_yourself)
- [Code Duplication Detection Tools](https://github.com/kucherenko/jscpd)
- [Refactoring Techniques](https://refactoring.guru/refactoring/smells/duplicate-code)